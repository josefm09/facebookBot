#adeudo predial
https://pagos.culiacan.gob.mx/mipredio/07001001001001001

#Directorio
###dependencias
http://transparencia.culiacan.gob.mx/api/directorio/dependencias
###adeudo
http://transparencia.culiacan.gob.mx/api/directorio/funcionarios

#Tramites y servicios
http://transparencia.culiacan.gob.mx/api/dependencia/tramites_y_servicios